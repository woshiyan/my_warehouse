<template>
	<view>
		<view class="seach">
			<input type="text" @input="onKeyInput" placeholder="搜索国家/地区" :value="inputValue" />
		</view>
		<view class="seach_center">
			<view class="seach_list" v-for="(item,index) in seach_list" :key="index" :data-img="item.countryIcon" :data-contryname="item.chineseName" :data-index="index" :data-rate="item.rate" :data-currencyname="item.currencyName" :data-currency="item.currency" :data-id="item.id" @tap="pickedContry">
				<image class="seach_img pull_left" :src="item.countryIcon"></image>
				<view class="seach_contry pull_left">{{item.chineseName}}</view>
				<view class="seach_bizhong pull_left">{{item.currencyName}}({{item.currency}})</view>
				<image class="check" :class="cousedis==index?'none':''" src="../../../static/ic-unchecked.png"></image>
				<image class="checkimg" :class="checked==index?'block':''" src="../../../static/ic-checked.png"></image>
				<view class="clear"></view> 
			</view>
		</view>
	</view>
</template>

<script>
	import {comRequest} from '@/common/index.js'
	import {comGetLoginInfo} from '@/common/index.js'
	export default {
		data() {
			return {
				inputValue:'',
				seach_list:[],
				checked:null,
				cousedis:null,
				contryname:'',
				currentTab:'',
				startpage:0,//开始页数
				size:10000,//每页多少条
			}
		},
		onLoad:function(options){
			this.contryname=options.contryname
			this.currentTab=options.currenttab 
			let that=this
			comGetLoginInfo(function(userInfo){
				comRequest({ 
					url: 'wxApplet/remittanceAreaList',
					method: 'GET',
					data: {
						name:that.inputValue,
						page: that.startpage,
						size: that.size,
					},
					success:  res => {
						if(res.data.status==1){
							that.seach_list=res.data.result
							if(that.contryname!=""){
								for(var i=0;i<that.seach_list.length;i++){
									if(that.seach_list[i].chineseName==that.contryname){
										that.checked=i
										that.cousedis=i
									}
								}
							}
						}
					}
				});
			});
		},
		methods: {
			onKeyInput(e){
				this.inputValue = e.target.value
				let that=this
				comGetLoginInfo(function(userInfo){
					comRequest({ 
						url: 'wxApplet/remittanceAreaList',
						method: 'GET',
						header: {
							'Content-Type': 'application/json',
							'token':userInfo.token 
						},
						data: {
							name:that.inputValue,
							page: that.startpage,
							size: that.size,
						},
						success:  res => {
							if(res.data.status==1){
								that.seach_list=res.data.result
								if(that.contryname!=""){
									for(var i=0;i<that.seach_list.length;i++){
										if(that.seach_list[i].chineseName==that.contryname){
											that.checked=i
											that.cousedis=i
										}
									}
								}
							}
						}
					});
				})
			},
			pickedContry(e){
				this.checked=e.currentTarget.dataset.index
				this.cousedis=e.currentTarget.dataset.index
				uni.redirectTo({
					url: '../../rentalHouse/rentRemittance/rentRemittance?img='+e.currentTarget.dataset.img+"&contryname="+e.currentTarget.dataset.contryname+"&rate="+e.currentTarget.dataset.rate+"&currencyname="+e.currentTarget.dataset.currencyname+"&currency="+e.currentTarget.dataset.currency+"&id="+e.currentTarget.dataset.id+"&currenttab="+this.currentTab
				});
			}
		}
	}
</script>

<style>
	.clear{
		clear: both;
	}
	.pull_left{
		float: left;
	}
	.seach{
		width: 100%;
		height: 80upx;
		padding: 40upx 0 32upx 0;
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		background: white;
	}
	.seach input{
		width: 680rpx;
		height: 80upx;
		margin: 0 auto;
		text-align: center;
		font-size: 28upx;
		color: #131313;
		background: #F4F4F4;
		border-radius: 40upx;
	}
	.seach_center{
		box-sizing: border-box;
		padding: 0 36upx 36upx 36upx;
	}
	.seach_center{
		margin-top: 152upx;
	}
	.seach_list{
		padding: 32upx 0;
	}
	.seach_img{
		width: 48upx;
		height: 48upx;
	}
	.seach_contry{
		margin:0 20upx;
		width: 240upx;
		overflow: hidden;
		color: #1D2129;
		line-height: 48upx;
		font-weight: bold;
		font-size: 28upx;
	}
	.seach_bizhong{
		width: 270upx;
		line-height: 48upx;
		margin-right: 20upx;
	}
	.check{
		width: 48upx;
		height: 48upx;
		vertical-align: middle;
	}
	.checkimg{
		width: 48upx;
		height: 48upx;
		vertical-align: middle;
		display: none;
	}
	.block{
		display: block;
	}
	.none{
		display: none;
	}
</style> 
