<template>
	<view class="viewbody"> 
		<view class="header">
			<com-steps :active="active" step_1="付款信息" step_2="汇款信息" step_3="在线支付"></com-steps>
		</view>
		<view v-show="switchStep(1)">
			<view class="content_tab">
				<view class="tab_header">
					<view :class="currentTab==1?'tab_active':''" :data-current="1" @tap="clickTab">周期付款</view>
					<view :class="currentTab==2?'tab_active':''" :data-current="2" @tap="clickTab">交定金</view>
				</view>
				<view class="content">
					<view class="tab1">
						<view class="uni-list-cell">
							<view class="uni-list-cell-left">
								国家/地区
							</view>
							<view class="uni-list-cell-db">
								<view class="uni-input" @tap="chooseContry">
									<image class="changecontry" :src="contryimg"></image>
									<text class="contrytext">{{contryname}}</text>
								</view>
								<image class="uni_img" src="../../../static/ic_more_arrow.png"></image>
							</view>
						</view>
						<view class="uni-list-cell" v-show="isShow">
							<view class="uni-list-cell-left">
								月租金
							</view>
							<view class="uni-list-cell-db">
								<input type="number" style="padding-right: 180upx;" placeholder="请输入每月租金" v-model="monthlyRent" @input="onKeyInput" class="input_mouth" />
								<text class="currency">{{currencyname}}（{{currency}}）</text>
							</view>
						</view>
						<view class="uni-list-cell" v-show="isdingjin">
							<view class="uni-list-cell-left">
								定金金额
							</view>
							<view class="uni-list-cell-db">
								<input type="number" style="padding-right: 180upx;" placeholder="请输入定金金额" v-model="dingjin" @input="onKeydingjin" class="input_mouth" />
								<text class="currency">{{currencyname}}（{{currency}}）</text>
							</view>
						</view>
						<view class="uni-list-cell" v-show="isShow">
							<view class="uni-list-cell-left">
								付款周期
							</view>
							<view class="uni-list-cell-db">
								<picker @change="bindPickerChangezhouqi" :value="indexzhouqi" :range="arrayzhouqi">
									<view class="uni-input">{{arrayzhouqi[indexzhouqi]}}</view>
								</picker>
								<image class="uni_img" src="../../../static/ic_more_arrow.png"></image>
							</view>
						</view>
						<view class="uni-list-cell" v-show="isShow">
							<view class="uni-list-cell-left">
								付款日期
							</view>
							<view class="uni-list-cell-db">
								<picker @change="bindPickerChangedate" :value="indexdate" :range="arraydate">
									<view class="uni-input">{{arraydate[indexdate]}}</view>
								</picker>
								<image class="uni_img" src="../../../static/ic_more_arrow.png"></image>
							</view>
						</view>
						<view class="uni-list-cell" v-show="isShow">
							<view class="uni-list-cell-left">
								押金
							</view>
							<view class="uni-list-cell-db">
								<picker @change="bindPickerChangeyajin" :value="indexyajin" :range="arrayyajin">
									<view class="uni-input">{{arrayyajin[indexyajin]}}</view>
								</picker>
								<image class="uni_img" src="../../../static/ic_more_arrow.png"></image>
							</view>
						</view>
						<view class="uni-list-cell">
							<view class="uni-list-cell-left">
								活动码
							</view>
							<view class="uni-list-cell-db">
								<input type="number" placeholder="如有请填写" v-model="huodong" class="input_mouth" />
							</view>
						</view>
						<view class="uni-list-cell alljisuan">
							<view class="uni-list-cell-left">
								共计
							</view>
							<view class="uni-list-cell-db all_money">
								{{allmonthly}} {{currency}}
							</view>
						</view>
						<view class="uni-list-cell">
							<view class="uni-list-cell-left">
								汇率
							</view>
							<view class="uni-list-cell-db all_money">
								{{rate}} CNY/{{currency}}
								<image src="../../../static/ic_currency_lock@2x.png" style="margin-left: 10upx;width: 28upx;height: 36upx;vertical-align: middle;"
								 mode="widthFix"></image>
								<text style="font-size: 22upx;color: #20C5A0;line-height: 48upx;" @tap="showFeeTip">汇率锁定</text>
							</view>
						</view>
						<view class="uni-list-cell">
							<view class="uni-list-cell-left">
								手续费
							</view>
							<view class="uni-list-cell-db all_money">
								0 (<text class="jianmian">270 CNY</text>)
								<text class="discounts-tip">优惠0手续费</text>
							</view>
						</view>
						<view class="uni-list-cell">
							<view class="uni-list-cell-left">
								需支付
							</view>
							<view class="uni-list-cell-db all_money">
								{{allprice}} CNY
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="checkbox_center">
				<view class="checkbox-3">
					<view @tap="checkedbox" style="display: inline-block;">
						<image src="../../../static/ic-checked.png" v-show="checked"></image>
						<image src="../../../static/ic-unchecked.png" v-show="unchecked"></image>
						我同意 
					</view>
					<view style="display: inline-block;font-weight: bold;" @tap="topro">《狐獴留学助手缴费咨询服务协议》</view>
				</view>
				<view class="sure_btn" :class="sure_sure==1?'sure_style':''" @tap="sure_skip">
					确认
				</view>
			</view>
		</view>
		<view v-show="switchStep(2)">
			<view class="tab1 form_tab" style="padding-top: 32upx;">
				<view class="switch_head pull_left">收款账号</view>
				<view class="example pull_right" @tap="toexample">
					填写示例<image src="../../../static/ic_cir_info.png"></image>
				</view><view class="clear"></view>
				<view class="uni-list-cell">
					<view class="uni-list-cell-left">
						收款方名称
					</view>
					<view class="uni-list-cell-db">
						<input type="text" placeholder="名称" v-model="payeeName" class="input_mouth" />
					</view>
				</view>
				<view class="uni-list-cell">
					<view class="uni-list-cell-left">
						收款方地址
					</view>
					<view class="uni-list-cell-db">
						<input type="text" placeholder="地址" v-model="payeeAddress" class="input_mouth" />
					</view>
				</view>
				<view class="uni-list-cell">
					<view class="uni-list-cell-left">
						收款银行
					</view>
					<view class="uni-list-cell-db">
						<input type="text" placeholder="Swift Code" v-model="payeeBank" class="input_mouth" />
					</view>
				</view>
				<view class="uni-list-cell">
					<view class="uni-list-cell-left">
						收款账号
					</view>
					<view class="uni-list-cell-db">
						<input type="text" :placeholder="gathering" v-model="payeeNumber" class="input_mouth" />
					</view>
				</view>
				<view class="uni-list-cell" v-show="isClear">
					<view class="uni-list-cell-left">
						{{clearing}}
					</view>
					<view class="uni-list-cell-db">
						<input type="text" :placeholder="clearCenter" v-model="clearNumber" class="input_mouth" />
					</view>
				</view>
				<view class="uni-list-cell">
					<view class="uni-list-cell-left">
						备注
					</view>
					<view class="uni-list-cell-db">
						<input type="text" style="padding-right: 8upx;" placeholder="汇款附言，非必填" v-model="reference" class="input_mouth" />
					</view>
				</view>
				<view class="switch_head" style="margin-top: 32upx;">付款人信息</view>
				<view class="uni-list-cell">
					<view class="uni-list-cell-left">
						姓名
					</view>
					<view class="uni-list-cell-db">
						<input type="text" placeholder="拼音 如：SHENGWEN ZHENG" v-model="myName" class="input_mouth" />
					</view>
				</view>
				<view class="uni-list-cell">
					<view class="uni-list-cell-left">
						联系电话
					</view>
					<view class="uni-list-cell-db">
						<view class="uni-list-cell-db">
							<input type="text" placeholder="电话" maxlength="11" v-model="myPhone" class="input_mouth" />
						</view>
					</view>
				</view>
				<view class="uni-list-cell">
					<view class="uni-list-cell-left">
						联系邮箱
					</view>
					<view class="uni-list-cell-db">
						<input type="text" placeholder="邮箱" v-model="myEmail" class="input_mouth" />
					</view>
				</view>
				<view class="uni-list-cell">
					<view class="uni-list-cell-left">
						账单地址
					</view>
					<view class="uni-list-cell-db">
						<input type="text" placeholder="地址" v-model="myAddress" class="input_mouth" />
					</view>
				</view>
			</view>
			<view class="second_center">
				<view class="sure_btn" @tap="secondsure_skip">
					确认
				</view>
			</view>
		</view>
		<view v-show="switchStep(3)">
			<view class="three_center">
				<view class="three_title">订单信息</view>
				<view>
					<view class="pull_left orderNum">订单编号</view>
					<view class="pull_left orderDetail">{{ordernum}}</view>
					<view class="clear"></view>
				</view>
				<view>
					<view class="pull_left orderNum">付款人</view>
					<view class="pull_left orderDetail">{{orderpayname}}</view>
					<view class="clear"></view>
				</view>
				<view>
					<view class="pull_left orderNum">收款方</view>
					<view class="pull_left orderDetail">{{ordershouname}}</view>
					<view class="clear"></view>
				</view>
				<view>
					<view class="pull_left orderNum">付款周期</view>
					<view class="pull_left orderDetail">{{orderzhouqi}}</view>
					<view class="clear"></view>
				</view>
				<view class="bigline" style="padding-top: 16upx;">
					<view class="pull_left orderNum">汇款总额</view>
					<view class="pull_left orderDetail">{{orderallmoney}} {{orderCurrencyName}} {{ordercurrent}}</view>
					<view class="clear"></view>
				</view>
				<view class="bigline" style="padding-top: 16upx;">
					<view class="pull_left orderNum">手续费</view>
					<view class="pull_left orderDetail">
						0 (<text class="jianmian">270 CNY</text>)
						<text class="discounts-tip">优惠0手续费</text>
					</view>
					<view class="clear"></view>
				</view>
				<view class="bigline">
					<view class="pull_left orderNum">需支付</view>
					<view class="pull_left orderDetail">{{orderchina}} 人民币（CNY）</view>
					<view class="clear"></view>
				</view>
				<view class="bigline">
					<view class="pull_left orderNum" style="opacity: 0;">1</view>
					<view class="pull_left orderDetail">
						<image src="../../../static/ic_currency_lock@2x.png" style="width: 28upx;height: 36upx;vertical-align: middle;" mode="widthFix"></image>
						<text style="font-size: 22upx;color: #20C5A0;line-height: 48upx;" @tap="showFeeTip">汇率锁定</text>
					</view>
					<view class="clear"></view>
				</view>
				<view class="settime">
					<text>请在</text><uni-countdown ref="countdown" :show-day="false" color="#131313" splitorColor="#131313" /><text>内完成支付</text>
				</view>
			</view>
			<view class="down_center">
				<view class="three_title">
					<view class="down_title pull_left">选择支付方式</view>
					<view class="outher_title pull_right">申请狐獴旅支卡</view>
					<view class="clear"></view>
				</view>
				<radio-group @change="radioChange">
					<label>
						<view class="pull_left">
							<radio value="0" disabled />
						</view>
						<view class="pull_left downpay">
							<view class="payway">
								<text class="pay_title">狐獴旅支卡支付</text>
								<text class="payback">返现¥200.00</text>
							</view>
							<view class="payover">
								完成后返现到狐獴旅支卡账户中
							</view>
						</view><view class="clear"></view>
					</label>
					<label>
						<view class="pull_left">
							<radio value="1" checked/>
						</view>
						<view class="pull_left downpay">
							<view class="payway">
								<view class="pay_title pull_left">在线网银支付</view>
								<view class="payimg pull_right">
									<image src="../../../static/img_card_alliances@2x.png"></image>
								</view><view class="clear"></view>
							</view>
							<view class="payover">
								支持银联、MasterCard、Visa支付
							</view>
						</view><view class="clear"></view>
					</label>
				</radio-group>
			</view>
			<view class="bottom" @tap="mastpay">
				<view class="usepay">立刻支付</view>
			</view>
		</view>
	</view>
</template>

<script>
	import comSteps from '@/components/com-steps/com-steps.vue'
	import uniCountdown from '@/components/uni-countdown/uni-countdown.vue'
	import {comRequest,comGetLoginInfo,conmChannelPayment} from '@/common/index.js'
	import {comGetTimeInterval} from '@/common/dateAndTime.js'
	import {RentalHouseUserAgreementUrl,RentalHouseHelpUrl} from '@/common/env.js'
	export default {
		components: {
			comSteps,
			uniCountdown
		},
		data() {
			return {
				active:1,
				currentTab:1,
				arrayzhouqi: ['3个月', '6个月', '9个月', '12个月', '18个月', '24个月'],
				indexzhouqi: 3,
				everymonth:'',//多少个月
				arrayyajin: ['无押金', '1个月', '2个月', '3个月'],
				indexyajin: 0,
				isdingjin:false,
				dingjin:'',//定金金额
				isShow:true,
				sure_sure:0,
				monthlyRent:'',//月租金金额
				deposit:0,//押金金额
				contryimg:'',//默认国家图片
				contryname:'',//默认国家名称
				contryid:'',//国家ID
				currency:'',//币种
				currencyname:'',//币种名称
				rate:'',//汇率
				allmonthly:'0.00',//共计其他币种
				allprice:'0.00',//共计人民币金额
				startpage:0,//开始页数
				size:10000,//每页多少条
				reference:'',//备注
				arraydate: ['每月固定日选择','每月月初前', '每月10日前', '每月15日前','每月20日前','每月25日前'],
				indexdate: 0,
				tijiaodate:"",
				payeeName:'',//收款人姓名
				payeeAddress:'',//收款人地址
				payeeBank:'',//收款银行
				isClear:false,//是否显示清算号
				huodong:'',//活动码
				clearing:'',//清算说明
				clearCenter:'',//清算placeholder
				clearNumber:'',//清算提交数据
				payeeNumber:'',//收款账号
				gathering:'账号',//收款账号的placeholder
				myName:'',//姓名
				myPhone:'',//联系电话
				myEmail:'',//邮箱
				myAddress:'',//账单地址
				ordernum:'',//订单编号
				orderpayname:'',//订单付款人
				ordershouname:'',//订单收款人
				orderzhouqi:'',//订单收款周期
				orderallmoney:'',//订单国家总金额
				ordercurrent:'',//订单币种
				orderCurrencyName:'',//币种名称
				orderchina:'',//中国金额
				usepay:1,//用哪种方式支付
				checked:false,
				unchecked:true
			}
		},
		onLoad:function(options){
			if(options.contryname!=undefined){
				this.contryimg=options.img
				this.contryname=options.contryname
				this.rate=options.rate
				this.currencyname=options.currencyname
				this.currency=options.currency
				this.contryid=options.id
				this.currentTab=options.currenttab
			}else{
				let that=this
				comGetLoginInfo(function(userInfo){
					comRequest({ 
						url: 'wxApplet/remittanceAreaList', 
						method: 'GET',
						header: {
							'Content-Type': 'application/json',
							'token':userInfo.token 
						},
						data: {
							name:'英国',
							page: that.startpage,
							size: that.size,
						},
						success: res => {
							if(res.data.status==1){
								that.contryimg=res.data.result[0].countryIcon
								that.contryname=res.data.result[0].chineseName
								that.rate=res.data.result[0].rate
								that.currency=res.data.result[0].currency
								that.currencyname=res.data.result[0].currencyName
								that.contryid=res.data.result[0].id
							}
						}
					});
				})
			}
			if(this.currentTab==2){
				this.isShow=false;
				this.isdingjin=true
				this.reset();
			}else{
				this.isShow=true;
				this.isdingjin=false
				this.reset();
			}
		},
		methods: {
			changemonth(month){
				if(month==0){
					this.everymonth=3
				}else if(month==1){
					this.everymonth=6
				}else if(month==2){
					this.everymonth=9
				}else if(month==3){
					this.everymonth=12
				}else if(month==4){
					this.everymonth=18
				}else if(month==5){
					this.everymonth=24
				}
			},
			onKeyInput(e){
				this.changemonth(this.indexzhouqi)
				this.monthlyRent = e.target.value
				this.deposit=this.accMul(this.monthlyRent,this.indexyajin)
				let howmonth=parseInt(this.everymonth)+parseInt(this.indexyajin)
				if(this.monthlyRent!=0||this.monthlyRent!=""){
					this.allmonthly=this.accMul(howmonth,this.monthlyRent)
					this.allprice=this.accMul(this.allmonthly,this.rate).toFixed(2).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g,'$&,')
				}else{ 
					this.allprice="0.00"
					this.allmonthly="0.00"
				}
			},
			onKeydingjin(e){
				this.dingjin=e.target.value
				this.allmonthly=e.target.value
				if(this.dingjin!=0||this.dingjin!=""){
					this.allprice=this.accMul(this.allmonthly,this.rate).toFixed(2).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g,'$&,')
				}else{ 
					this.allprice="0.00"
					this.allmonthly="0.00"
				}
			},
			//Js乘法失真
			accMul(arg1, arg2) {
			  let m = 0,
			    s1 = arg1.toString(),
			    s2 = arg2.toString();
			  try {
			    m += s1.split(".")[1].length
			  } catch (e) {}
			  try {
			    m += s2.split(".")[1].length
			  } catch (e) {}
			  return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m)
			},
			//第一页tab切换重置页面
			reset(){
				this.allprice="0.00"
				this.indexzhouqi=3
				this.indexyajin=0
				this.deposit=0
				this.allmonthly="0.00"
			},
			// 第一页JS 
			clickTab(e) { 
				this.monthlyRent=""
				this.dingjin=""
				this.huodong=""
				this.indexdate=0
				if (this.currentTab === e.target.dataset.current) {
				  return false;
				} else {
					this.currentTab= e.target.dataset.current
				}
				if(e.target.dataset.current==1){
					this.isShow=true;
					this.isdingjin=false
					this.reset();
				}else{
					this.isShow=false;
					this.isdingjin=true
					this.reset();
				}
			},
			// 选择国家
			chooseContry(){
				uni.redirectTo({
					url: '../../rentalHouse/chooseContry/chooseContry?contryimg='+this.contryimg+"&contryname="+this.contryname+"&currenttab="+this.currentTab
				});
			},
			//选择周期
			bindPickerChangezhouqi(e) {
				this.indexzhouqi = e.target.value
				this.changemonth(e.target.value)
				if(this.monthlyRent!=0||this.monthlyRent!=""){
					let howmonth=parseInt(this.everymonth)+parseInt(this.indexyajin)
					this.allmonthly=this.accMul(howmonth,this.monthlyRent)
					this.allprice=this.accMul(this.allmonthly,this.rate).toFixed(2).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g,'$&,')
				}
			},
			//选择押金约束
			bindPickerChangeyajin(e) {
				this.indexyajin = e.target.value
				this.deposit=this.accMul(this.monthlyRent,this.indexyajin)
				if(this.monthlyRent!=0||this.monthlyRent!=""){
					let howmonth=parseInt(this.everymonth)+parseInt(this.indexyajin)
					this.allmonthly=this.accMul(howmonth,this.monthlyRent)
					this.allprice=this.accMul(this.allmonthly,this.rate).toFixed(2).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g,'$&,')
				}
			},
			// 是否同意
			checkedbox() {
				if(this.checked==false){
					this.checked=true;
					this.unchecked=false
					this.sure_sure=1
				}else{
					this.checked=false;
					this.unchecked=true
					this.sure_sure=0
				}
			},
			topro(){
				uni.navigateTo({
					url:"../../common/comWebView/comWebView?url="+RentalHouseUserAgreementUrl
				})
			},
			toexample(){
				uni.navigateTo({
					url:"../../common/comWebView/comWebView?url="+RentalHouseHelpUrl
				})
			},
			// 点击第一个确认按钮
			sure_skip(){
				if(this.sure_sure==1){
					if(this.currentTab==1){
						if(this.monthlyRent==""){ 
							uni.showToast({
								title:"请输入每月租金", 
								icon:"none",
							});
							return false
						}
						let reg=/^[0-9]*$/ 
						// let reg =/^([1-9]\d{0,9}|0)([.]?|(\.\d{1,2})?)$/
						if(!reg.test(this.monthlyRent)){
							uni.showToast({
								title:"请输入正确数字", 
								icon:"none",
							});
							return false
						}
						if(this.indexdate==0){
							uni.showToast({
								title:"请选择付款日期", 
								icon:"none",
							});
							return false
						}
						this.active = 2;
						this.determineAreas();
					}else{
						if(this.dingjin==""){ 
							uni.showToast({
								title:"请输入定金", 
								icon:"none",
							});
							return false
						}
						let reg=/^[0-9]*$/ 
						// let reg =/^([1-9]\d{0,9}|0)([.]?|(\.\d{1,2})?)$/
						if(!reg.test(this.dingjin)){
							uni.showToast({
								title:"请输入正确数字", 
								icon:"none",
							});
							return false
						}
						this.active = 2;
						this.determineAreas();
					}
				}
			},
			determineAreas(){
				if(this.currency=="USD"){
					this.isClear=true
					this.clearing="ABA"
					this.clearCenter="ABA/FW 清算号"
				}
				if(this.currency=="CAD"){
					this.isClear=true
					this.clearing="CC/TN"
					this.clearCenter="CC 或 TRANSIT NO 清算号"
				}
				if(this.currency=="EUR"){
					this.isClear=true
					this.clearing="SC"
					this.clearCenter="Short Code"
				}
				if(this.currency=="AUD"){
					this.isClear=true
					this.clearing="BSB/AU"
					this.clearCenter="BSB/AU 清算号"
				}
				if(this.currency=="GBP"){
					this.isClear=true
					this.clearing="SC"
					this.clearCenter="Short Code"
				}
			},
			switchStep(index){
				if (this.active == index) {
					return true;
				} else {
					return false;
				}
			},
			bindPickerChangedate(e) {
				this.indexdate = e.target.value
			},
			// 第二页确认按钮
			secondsure_skip(){
				var that=this
				let wanTxt = '';
				let reg =/\d{14}|\d{19}/ //验证银行卡号
				let isPhone =/^((13|14|15|16|17|18)[0-9]{1}\d{8})$/ //验证手机号
				let isEmail =/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/ //验证邮箱
				if(this.payeeName==''){
					wanTxt="请输入收款方名称"
				}else if(this.payeeAddress==''){
					wanTxt="请输入收款方地址"
				}else if(this.payeeBank==''){
					wanTxt="请输入收款方银行"
				}else if(this.payeeNumber==''){
					wanTxt="请输入收款方账号"
				}else if(!reg.test(this.payeeNumber)){
					wanTxt="请输入正确账号数字"
				}else if(this.myName==""){
					wanTxt="请输入付费人姓名"
				}else if(this.myPhone==""){
					wanTxt="请输入付费人电话"
				}else if(!isPhone.test(this.myPhone)){
					wanTxt="请输入正确手机号"
				}else if(this.myEmail==""){
					wanTxt="请输入付费人邮箱"
				}else if(!isEmail.test(this.myEmail)){
					wanTxt="请输入正确邮箱地址"
				}else if(this.myAddress==""){
					wanTxt="请输入账单地址"
				}else if(this.isClear==true){
					if(this.clearNumber==""){
						wanTxt="请输入清算号"
					}
				}
				if(wanTxt!=''){
					uni.showToast({
						title: wanTxt,
						icon: "none"
					});
				}else{
					if(this.indexdate==1){
						this.tijiaodate=5
					}else if(this.indexdate==2){
						this.tijiaodate=10
					}else if(this.indexdate==3){
						this.tijiaodate=15
					}else if(this.indexdate==4){
						this.tijiaodate=20
					}
					else if(this.indexdate==5){
						this.tijiaodate=25
					}
					//从本地缓存获取用户登录信息  
					comGetLoginInfo(function(userInfo){
						if(userInfo.loginUser.phone==""){
							uni.showToast({
								title:'请先绑定手机号', 
								icon:"none",
							});
							setTimeout (()=> {
								uni.navigateTo({
									url: '../../register/phoneValid/phoneValid'
								})
							}, 1000);
						}else{
							comRequest({ 
								url: 'wxApplet/addRentHouseOrder',
								method: 'POST',
								header:{
									"Content-Type": "application/json",
									'token':userInfo.token 
								},
								data: {
									referenceId:"",//付款参考号
									remittanceAreaId:that.contryid,//是汇款地区
									monthRental:that.monthlyRent,//每月租金
									paidMonth:that.everymonth,//付款周期
									deposit:that.deposit,//押金
									rentPayDate:that.tijiaodate,//租金打款日期
									receiveName: that.payeeName,//收款方名称
									receiveAddress:that.payeeAddress,//收款方地址
									receiveBankName:that.payeeBank,//收款银行
									receiveBankNo:that.payeeNumber,//收款银行账号
									remark:"",//订单备注
									orderAmount:that.allmonthly,//订单金额
									payRemark:that.reference,//支付备注
									payerName:that.myName,//付款人姓名
									payerMobile:that.myPhone,//付款人手机号
									payerEmail:that.myEmail,//付款人邮箱
									payerAddress:that.myAddress,//付款人地址 
									activityCode:that.huodong,//活动码
									liquidationNo:that.clearNumber,//清算号
									type:that.currentTab,//订单类型
								},
								success: res => {
									if(res.data.status==1){
										that.setExpreTime(res.data.result.order.createTime);
										that.ordernum=res.data.result.order.orderNo//订单编号
										that.orderpayname=res.data.result.order.payerName//订单付款人
										that.ordershouname=res.data.result.order.receiveName//订单收款人
										that.orderzhouqi=res.data.result.order.paidMonth//订单收款周期 
										that.orderallmoney=res.data.result.order.orderAmount//订单国家总金额
										that.ordercurrent=res.data.result.order.orderCurrency//订单币种
										that.orderchina=res.data.result.order.payAmount//中国金额 
										that.orderCurrencyName=res.data.result.order.orderCurrencyName;
										that.active = 3;
									}
								}
							});
						}
					})
				}
			},
			setExpreTime: function(dt){
				let startDate = new Date(dt);
				startDate.setDate(startDate.getDate()+1);
				let endDate = new Date();
				let expireTime = comGetTimeInterval(endDate,startDate);
				let expire ={
					day:expireTime.day,
					hour:expireTime.hour,
					minute:expireTime.minute,
					second:expireTime.second-2
				};
				this.$refs.countdown.startCountDown(expire);
			},
			radioChange(e){
				this.usepay=e.target.value
			},
			mastpay(){
				if(this.usepay==1){
					//网银支付
					let that=this
					conmChannelPayment({
						payChannelCode:"OnlineBankingPay",
						orderNo:that.ordernum
					})
				}else{
					//狐獴支付
				}
			},
			showFeeTip() {
				uni.showModal({
					title: "汇率保护",
					content: "下单时会锁定当前汇率，在订单支付有效期内支付不再受到汇率变化影响。汇率锁定保护服务由狐蒙金服提供。",
					showCancel: false,
					confirmText: "关闭"
				})
			}
		}
	}
</script>

<style>
	.clear{
		clear: both;
	}
	.pull_left{
		float: left;
	}
	.pull_right{
		float: right;
	}
	page{
		background: #F4F4F4;
	}
	.header {
		position: relative;
		border-bottom-left-radius: 64upx;
		border-bottom-right-radius: 64upx;
		overflow: hidden;
		background:#FDDE5C;
	}
	.tab_header{
		width: 614upx; 
		display: -webkit-flex; /* Safari */
		display: flex;
		margin: 52upx auto auto auto;
		box-sizing: border-box;
	}
	.tab_header view{
		width: 50%;
		text-align: center;
		font-size: 32upx;
		color: rgba(29,33,41,0.5);
		font-weight: bold;
		height: 64upx;
		line-height: 64upx;
	}
	.tab_active{
		border-radius: 70upx;
		background: #FFD353;
		color: #131313 !important;
	}
	.tab1 {
		box-sizing: border-box;
		padding: 48upx 34upx 0 34upx;
	} 
	.discounts-tip {
		margin-left: 20upx;
		font-size: 24upx;
		color: #20C5A0;
		line-height: 48upx;
		border: 1px solid #20C5A0;
		border-radius: 12upx;
		padding: 0 14upx;
	}
	.content_tab{
		background: white;
		overflow: hidden;
		margin: 32upx 20upx 0 20upx;
		border-radius: 32upx;
		padding-bottom: 48upx;
	}
	.uni-list-cell {
		position: relative;
	}

	.uni-list-cell-left {
		color: rgba(19, 19, 19, 0.5);
		font-size: 26upx;
		width: 144upx;
		padding: 0;
	}

	.uni-list-cell::after {
		height: 0;
	}

	.uni-input {
		border-bottom: 2upx solid rgba(216, 216, 216, 0.5);
		padding: 15upx 0;
		margin-left: 24upx;
	}

	.uni_img {
		width: 48upx;
		height: 48upx;
		position: absolute;
		right: 0;
		top: 16upx;
	}
	.changecontry{
		width: 48upx;
		height: 48upx;
		vertical-align: middle;
		margin-right: 8upx;
	}
	.contrytext{
		font-size: 28upx;
		color: #131313;
	}
	.input_mouth {
		font-size: 28upx;
		border-bottom: 2rpx solid rgba(216, 216, 216, 0.5);
		padding: 15rpx 0;
		margin-left: 24rpx;
		height: 50rpx;
		line-height: 50rpx;
		font-size: 28rpx;
		background: #FFF;
		-webkit-box-flex: 1;
		-webkit-flex: 1;
		-ms-flex: 1;
		flex: 1;
		color: #131313;
	}

	.currency {
		position: absolute;
		top: 16upx;
		right: 0;
		color: #131313;
		font-weight: bold;
	}

	.all_money {
		font-size: 24upx;
		padding-left: 24upx;
		color: #131313;
		font-weight: bold;
	}
	.jianmian{
		text-decoration:line-through;
	}
	.alljisuan{
		margin-top: 32upx;
	}
	.explain {
		font-size: 24upx;
		margin-left:24upx;
		line-height: 48upx;
		color: #131313;
	}

	.ic_info,
	.ic_right {
		float: left;
		margin-top: 16upx;
	}

	.ic_info {
		width: 32upx;
		height: 32upx;
		margin: 32upx 20upx 0 116upx;
	}

	.ic_right view {
		line-height: 32upx;
		font-size: 24upx;
		color: rgba(19, 19, 19, 0.5);
	}

	checkbox .wx-checkbox-input {
		border-radius: 50%;
		transform: scale(0.8);
		color: #ccc;
	}

	checkbox .wx-checkbox-input.wx-checkbox-input-checked {
		border: 2upx solid #20C5A0;
		background: #20C5A0;
	}

	checkbox .wx-checkbox-input.wx-checkbox-input-checked::before {
		border-radius: 50%;
		text-align: center;
		font-size: 30rpx;
		color: #fff;
		background: transparent;
		transform: translate(-50%, -50%) scale(0.8);
		-webkit-transform: translate(-50%, -50%) scale(0.8);
	}
	.checkbox_center{
		margin: 80upx auto;
		text-align: center;
		width: 100%;
	}
	.checkbox-3{
		margin-right: 16upx;
		font-size: 28upx;
		color: #434040;
	}
	.checkbox-3 image{
		width: 40upx;
		height: 40upx;
		vertical-align: middle;
		margin-right: 16upx;
	}
	.sure_btn{
		width: 470upx;
		height: 96upx;
		line-height: 96upx;
		border-radius: 96upx;
		margin: 32upx auto;
		background: rgba(255,210,82,0.5);
		font-size: 32upx;
		color: rgba(19, 19, 19, 0.5);
	}
	.sure_style{
		color: #131313;
		background: #FFD253;
	}
	.switch_head{
		font-size: 32upx;
		font-weight: bold;
		color: #131313;
		line-height: 48upx;
		margin-bottom: 16upx;
	}
	.example view{
		color: rgba(19,19,19,0.5);
		font-size: 24upx;
		line-height: 48upx;
	}
	.example image{
		width:32upx;
		height: 32upx;
		margin-left: 16upx;
		vertical-align: middle;
	}
	.second_center{
		margin-top: 94upx;
		text-align: center;
	}
	.form_tab{
		margin: 32upx 20upx 0 20upx;
		background: white;
		border-radius: 32upx;
		padding-bottom: 32upx;
	}
	.second_center view{
		color: #131313;
		background: #FFD353;
	}
	.three_center,.down_center{
		box-sizing: border-box;
		padding: 36upx 36upx 0 36upx;
	}
	.three_center{
		padding-bottom: 36upx;
		margin: 32upx 20upx 0 20upx;
		background: white;
		border-radius: 32upx;
	}
	.down_center{
		border-top: 32upx solid #f4f4f4;
		padding-bottom: 190upx;
		background: white;
	}
	.three_title{
		font-size: 32upx;
		color: #131313;
		font-weight: bold;
		line-height: 48upx;
		padding-bottom: 16upx;
		margin-bottom: 32upx;
		border-bottom: 2upx solid #D8D8D8;
	}
	.orderNum{
		width: 160upx;
		font-size: 24upx;
		color: rgba(19,19,19,0.5);
		margin-right: 20upx;
		text-align: right;
	}
	.orderDetail{
		font-size: 24upx;
		color: #131313;
		font-weight: bold;
		line-height: 36upx;
	}
	.bigline view{
		line-height: 48upx;
		font-size: 28upx !important;
	}
	.orderNum image{
		width: 32upx;
		height: 32upx;
	}
	.orderDetail view{
		font-size: 24upx;
		color: rgba(19,19,19,0.5);
		line-height: 32upx;
	}
	.outher_title{
		font-size: 28upx;
		color: rgba(19,19,19,0.5);
	}
	.down_title{
		font-size: 32upx;
		color: #131313;
		font-weight: bold;
		line-height: 48upx;
	}
	.payway{
		margin-left: 16upx;
	}
	.downpay{
		width: calc(100% - 70upx);
	}
	radio-group label, checkbox-group label {
		padding-right: 0;
	}
	radio .wx-radio-input{
	    border-radius: 50%;/* 圆角 */
	    transform: scale(0.8);
	}
	.pay_title{
		font-size: 32upx;
		font-weight: bold;
		line-height: 48upx;
		margin: 0 20upx 0 0;
		color: #131313;
	}
	.payback{
		display: inline-block;
		height: 48upx;
		line-height: 48upx;
		box-sizing: border-box;
		padding: 0 8upx;
		border: 2upx solid #20C5A0;
		color: #20C5A0;
		font-size: 24upx;
		border-radius: 12upx;
	}
	.payover{
		font-size: 24upx;
		color: #131313;
		margin:16upx 0 0 16upx;
	}
	.payimg image{
		width: 148upx;
		height: 32upx;
		vertical-align: middle;
	}
	.downpay{
		padding-bottom: 30upx;
		border-bottom: 2upx solid #D8D8D8;
		margin-bottom: 16upx;
	}
	.settime{
		margin-top: 32upx;
		text-align: center;
		color: #131313;
		font-weight: bold;
	}
	.bottom{
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
		background: #20C5A0;
		text-align: center;
	}
	.usepay{
		color: white;
		line-height: 80upx;
		font-weight: 500;
		font-size: 36upx;
		padding: 32upx 0 56upx 0;
		font-weight: bold;
	}
	.useback{
		color: white;
		font-size: 32upx;
		line-height: 32upx;
		padding-bottom: 56upx;
	}
</style>
